# README

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for?

- Quick summary
- Version
- [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up?

## Set Up & How to Run Tests

# Before you can run this application there is a simple set up you must do.

1. Download node <https://nodejs.org/en/download/> -> If this done, skip this step

2. Run npm install -> to install all packages and dependencies

(To learn more about npm https://docs.npmjs.com/)

# How to build the code

1. npm run build
2. Sometimes on the first build you'll also need run:
node node_modules/protractor/bin/webdriver-manager update

# How to run test only?

1. npm run e2e:script
2. If that doesn't work, run this directly from the root of the main folder:
   ./node_modules/protractor/bin/protractor e2e/protractor.conf.js

# How to run in headless mode?

1. e2e:script-headless
2. If that doesn't work, run this directly:
  ./node_modules/protractor/bin/protractor e2e/protractor.conf.js --capabilities.chromeOptions.args='--headless'


## Configuration

- The protactor.conf.js defines how your test classes will be accessed, browser configuation and localhost configurations. This file should not be changed too much except for the CAPABILITIES portion which you will change to fit your project requirement and needs. (Chrome, Firefox, etc.)

## Deployment instructions


### Contribution guidelines

## Writing tests

- This project follows the page object model. You will create functions that define the webelement you wish to test and interact with. These test classes will work with additional object classes. The idea behind page object model to decrease duplicate work and ensure consistency/reliability. (https://martinfowler.com/bliki/PageObject.html )

## Structural Break Down

-- NOTE : Every test lives under the e2e/src folder

# Pages Folder:

- This folder defines all of the page classes. If a page has object classes, the object classes will exist under the specified page folder. (ie DashboarPage -> dashboard.page.ts & search.object.ts). If you find an object class is used among multiple web pages, then this class should exist under a common object folder

# Spec Folder:

- The spec folder is where all the test classes exist. You will need to specify this folder location in you protractor configuration file, so that your tests are successfully picked up

# Util Folder:

- The util folder contains, classes such as the helper methods class and the promise handler class. This folder is a great place for classes that are consistently used throughout your project. It is also a great location to hold all of your constants files.

## How to Create A Test

# Defining custom attributes

- In TS you can create customized attribute that will be used in the grabbing the webelement from the page. These custom attributes will exist in the HTML file of the production code.

- This project has a custom attribute defined as [attr.data-automation]="constanstFile.ElementName" . In order to use this attribute you need to define the constants file in the component class. In this example your constantsfile name is "ConstantsFile", you will define in the component class, so that typescript know to grab the file and the element name you defined to be part of the HTML.

(Search [attr.data-automation] and you will be able to find all areas in the HTML where these custom attributes were defined.)

# Create a Test Class

- Every test class will have at least describe and an it function. The Describe encapsulates the it functions is a great way to break your tests into defining sections. You can also utilize beforeEach()/beforeAll() or afterEach()/afterAll() to setup and break down tests.

- The First thing you will need to do is defined a describe. Inside of that describe you can create a before each which will set up all functionality that needs to occur before your test can run. Finally, you create an it function and this is that actual test case.

# Tips & Tricks

- Placing an f in front of the describe or it function will only run the test case(s) defined by the f
- Placing an x in front of the describe or it function will skip the test case(s) defined by the x
- To debug utilize console.log() this will help you in the debugging process

### Contribution Guidelines for Branching

- Creating new Feature feature/{story#}-{Desc}
- Fixing a bug bugfix/{story#}-{Desc}
- Creating a hotfix hotfix/{story#}-{Desc}

### Who do I talk to?

- Kelsey Davis, Cody Dixon, Young Kim & Josh Dripps
- Additional resources can be found in our SLALOM MEDIUM DOCUMENTS, specifically Page Object Model

# Protractor-typescript-jasmine README

## Description

- Protractor is a selenium based testing framework that is used in angular based projects. Protractor is a part of the angular library system, this means it requires little setup. In order to properly set up your tests and how you expect them to run, will only need to be defined in the protractor.conf.js.

- Protractor can support multiple browsers and can even support mobile browser testing. You can even run multiple browser at one time upon running your tests. Protractor can even run headless and, again, is simple to integrate into your project. Protractor is a common typescript UI testing framework. This means there is a lot of supporting documentation.

## Table of Contents

<Table of Contents must link to all Markdown sections in the file and be at least one-depth (must capture all ## headings)>

## Requirements

<Requirements section must make it clear whether the framework requires outside dependencies to work (modules, libraries, etc.) and link to those requirements.>

## Installation

1. Run npm install

## Demonstration

<Demonstration must adhere to Framework Demonstration.>

## Tests

1. UI Test - npm run e2e
2. Unit Tests - npm run test

## Reports

Three report types are included in this framework:

- JSON - [jasmine-spec-reporter](https://www.npmjs.com/package/jasmine-spec-reporter)
- HTML - [protractor-beautiful-reporter](https://www.npmjs.com/package/protractor-beautiful-reporter)
- Junit XML - [jasmine-reporters](https://www.npmjs.com/package/jasmine-reporters)

Reporting settings are configured in the `onPrepare` function in `e2e/protractor.conf.js`. As an example, a SpecReporter from the jasmine-spec-reporter package is configured here:

```
jasmine.getEnv().addReporter(new SpecReporter({
  spec: {displayStacktrace: true}
}));
```

## Tool Specific Information

The framework is using jasmine. On how to further understand how to utilize jasmine here follow the link here https://jasmine.github.io/
