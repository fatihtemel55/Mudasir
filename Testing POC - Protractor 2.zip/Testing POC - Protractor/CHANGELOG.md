# Changelog

All notable changes to this project will be documented in this file.

## [0.10.2] - 2020-09-25

### Added

- Added .gitlab-ci sample file
- Updates to readme file
- Add NPM script to run protractor script only
- Add test sample using timestamp
- Add test sample using parameterization
- Add headless commandline script

### Changed

- Refactor details page test
- Refactor heroes page test
- Set Loglevel to ERROR

## [0.10.1] - 2020-08-14

### Added

- Added changelog file
- Added .gitignore file

### Changed

- Refactored the code base to follow Page Object model
- Added awaits and utils files to support tests and test classes

## [0.10.0] - 2020-08-07

### Added

- Added html and xml report packages to package.json/package-lock.json
- Added report directory structure
- Added html and xml reporters to jasmine env in protractor config
- Added initial page object files

### Changed

- Updated the README.md to use the template specified by the reusable artifacts confluence docs, and filled in the Reports section.
- Changes to Protractor config to run in headless mode

## [0.0.0] - 2020-07-30

### Added

- Added changelog file
- Added .gitignore file

### Changed

- Changed package version to 0.0.0 to indicate artifact should not be considered stable
