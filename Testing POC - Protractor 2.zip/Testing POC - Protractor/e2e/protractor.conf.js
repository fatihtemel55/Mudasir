// @ts-check
// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts

const HtmlReporter = require("protractor-beautiful-reporter");
const jasmineReporters = require("jasmine-reporters");
const { SpecReporter } = require("jasmine-spec-reporter");
const { browser } = require("protractor");

/**
 * @type { import("protractor").Config }
 */
exports.config = {
  allScriptsTimeout: 11000,
  specs: ["./src/**/*.e2e-spec.ts"],
  capabilities: {
    browserName: "chrome",
    chromeOptions: {
      args: ["--no-sandbox", "--disable-gpu", "--window-size=1200,1200"],
    },
  },
  logLevel: "ERROR",
  directConnect: true,
  baseUrl: "https://codepen.io/shawncummins/pen/XWKNxmQ?center=-84.4547367095995,42.24001977479737",
  framework: "jasmine",
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000,
    print: function () { },
  },

  plugins: [
    {
      package: 'protractor-react-selector',
    }
  ],

  onPrepare: function () {
    require("ts-node").register({
      project: require("path").join(__dirname, "./tsconfig.json"),
    });

    jasmine.getEnv().addReporter(
      new SpecReporter({
        spec: { displayStacktrace: true },
      })
    );

    jasmine.getEnv().addReporter(
      new HtmlReporter({
        baseDirectory: "reports/html",

        screenshotsSubfolder: "screenshots",

        jsonsSubfolder: "jsons",
      }).getJasmine2Reporter()
    );

    jasmine.getEnv().addReporter(
      new jasmineReporters.JUnitXmlReporter({
        savePath: "reports/xml",

        consolidateAll: false,
      })
    );
  },
  // Sets the output location for the json SpecReporter
  resultJsonOutputFile: "reports/json/report.json",
};
