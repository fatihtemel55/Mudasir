// import DashboardPage from "../pages/dashboardPage/dashboard.page";
// import { browser, element, by } from "protractor";
// import { HelperMethods } from "../util/helper-methods";
// import { DashboardConstants } from "../util/constants/dashboard-constants";
// import DetailsPage from "../pages/detail.page";
// import { DetailsPageConstants } from "../util/constants/detail-constants";
// import { protractor } from "protractor/built/ptor";

// describe("Heros: Details Page - ", () => {
//   let dashboardPage: DashboardPage;
//   let detailsPage: DetailsPage;

//   beforeEach(async (done) => {
//     HelperMethods.navigateToDashboard();
//     await browser.refresh();
//     const dashboardPageContainer = await element(
//       by.css(`[data-automation=${DashboardConstants.dashboardContainer}`)
//     );

//     await browser.wait(
//       protractor.ExpectedConditions.presenceOf(
//         await element(
//           by.css(`[data-automation=${DashboardConstants.dashboardTitle}`)
//         )
//       ),
//       5000,
//       `${DashboardConstants.dashboardTitle} taking too long to appear in the DOM (waitForDashboardToAppear())`
//     );

//     dashboardPage = new DashboardPage(dashboardPageContainer);
//     const listOfHeros = await dashboardPage.topHerosButtons();
//     await listOfHeros[0].click();
//     await browser.wait(
//       protractor.ExpectedConditions.presenceOf(
//         await element(
//           by.css(`[data-automation=${DetailsPageConstants.detailsPageHeader}`)
//         )
//       ),
//       5000,
//       `${DetailsPageConstants.detailsPageHeader} taking too long to appear in the DOM (waitForDashboardToAppear())`
//     );
//     const detailsPageContainer = await element(
//       by.css(`[data-automation=${DetailsPageConstants.detailsPageHeader}`)
//     );
//     detailsPage = new DetailsPage(detailsPageContainer);

//     return done();
//   });

//   // Test that the elements on the page are displayed on the UI and the elements have the
//   // Appropriate text if applicable
//   it("Elements Appear as Expected", async () => {
//     expect(await detailsPage.isDisplayed()).toBeTruthy();
//     expect(await detailsPage.getDetailsPageTitle.getText()).toEqual(
//       "NARCO Details"
//     );
//     expect(await detailsPage.getHeroId.getText()).toEqual("id: 12");
//     expect(await detailsPage.getInputBoxHeader.getText()).toEqual("name:");
//     expect(await detailsPage.getGoBackButton.getText()).toEqual("go back");
//     expect(await detailsPage.getSaveButton.getText()).toEqual("save");
//   });
// });
