// import DashboardPage from "../pages/dashboardPage/dashboard.page";
// import { element, by } from "protractor";
// import { HelperMethods } from "../util/helper-methods";
// import { DashboardConstants } from "../util/constants/dashboard-constants";

// describe("Heros: Dashboard Page - ", () => {
//   let dashboardPage: DashboardPage;

//   beforeEach(async (done) => {
//     HelperMethods.navigateToDashboard();
//     const dashboardPageContainer = await element(
//       by.css(`[data-automation=${DashboardConstants.dashboardContainer}`)
//     );

//     dashboardPage = new DashboardPage(dashboardPageContainer);

//     return done();
//   });

//   // Test that the elements on the page are displayed on the UI and the elements have the
//   // Appropriate text if applicable
//   it("Elements Appear as Expected", async () => {
//     // Expect Header Section Appears as expected
//     const headersection = await dashboardPage.headerSection();
//     expect(await headersection.isDisplayed()).toBeTruthy();
//     expect(await headersection.PageHeader.getText()).toEqual("Tour of Heroes");
//     expect(await headersection.HerosTab.getText()).toEqual("Heroes");
//     expect(await headersection.DashboardTab.getText()).toEqual("Dashboard");

//     // Top Heroes Section
//     expect(await dashboardPage.topHerosTitle.getText()).toEqual("Top Heroes");
//     expect(await (await dashboardPage.topHerosButtons()).length).toEqual(4);

//     // Search Section
//     const searchSection = await dashboardPage.searchSection();
//     expect(await searchSection.isDisplayed()).toBeTruthy();
//     expect(await searchSection.SearchHeader.getText()).toEqual("Hero Search");
//   });
// });
