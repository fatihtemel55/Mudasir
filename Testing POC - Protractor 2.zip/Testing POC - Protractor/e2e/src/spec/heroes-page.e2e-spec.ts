// import HeroesPage from "../pages/heroesPage/heroes.page";
// import DetailsPage from "../pages/detail.page";
// import { element, by } from "protractor";
// import { HelperMethods } from "../util/helper-methods";

// describe("Heroes: Heroes Page - ", () => {
//   let heroesPage: HeroesPage;
//   let detailsPage: DetailsPage;

//   beforeEach(async (done) => {
//     HelperMethods.navigateToHeroes();
//     const heroesPageContainer = await element(
//       by.css("app-heroes")
//     );

//     heroesPage = new HeroesPage(heroesPageContainer);
//     detailsPage = new DetailsPage(heroesPageContainer);
//     return done();
//   });

//   // Test that the elements on the page are displayed on the UI and the elements have the
//   // Appropriate text if applicable
//   it("Elements Appear as Expected", async () => {
//     const headerSection = await heroesPage.headerSection();
//     expect(await headerSection.isDisplayed()).toBeTruthy();
//     expect(await headerSection.PageHeader.getText()).toEqual("Tour of Heroes");
//     expect(await headerSection.HerosTab.getText()).toEqual("Heroes");
//     expect(await headerSection.DashboardTab.getText()).toEqual("Dashboard");
//     expect(await heroesPage.isDisplayed()).toBeTruthy();
//   });

//   const testValue = `Time Master ${new Date().getTime()}`

//   it(`Hero, ${testValue}, can be added`, async () => {
//     heroesPage.heroInputField.sendKeys(testValue);
//     heroesPage.heroAddButton.click();
//     expect(await heroesPage.heroBadgeAll.getText()).toMatch(testValue);
//   });

//   const parameters = [
//     { description: "Detail page for hero Narco displays", input: "Narco"},
//     { description: "Detail page for hero Dr Nice displays", input: "Dr Nice"},
//     { description: "Detail page for hero Magma displays", input: "Magma"}
//   ]

//   parameters.forEach((parameter) => {
//     it(parameter.description, async () => {
//       const testValue = parameter.input;
//       heroesPage.getHeroBadgeByText(testValue).click();
//       expect(await detailsPage.getDetailsPageTitle.getText()).toContain(testValue.toUpperCase());
//     });
//   })
// });
