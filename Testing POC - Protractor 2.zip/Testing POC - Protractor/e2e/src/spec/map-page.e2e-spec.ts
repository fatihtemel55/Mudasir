import { browser, by, element, protractor, Config } from "protractor";
//import MapPage from "../pages/MapPage/map.page";
import { HelperMethods } from "../util/helper-methods";
import { MapConstants } from "../util/constants/map-constants";
import { assert } from "console";
var Request = require("request");

describe("Map: Map Page - ", () => {
  beforeEach(async (done) => {
    browser.waitForAngularEnabled(false);
    // TODO: might need to wait for react once we are on the real site
    HelperMethods.navigateToMap(1000);

    return done();
  });

  afterEach(async (done) => {
    browser.sleep(5000);

    return done();
  });

  it('should search an address', async function() {
    const iframe = browser.element(by.id(MapConstants.iFrame)).getWebElement();
    browser.switchTo().frame(iframe);

    browser.element(by.css(MapConstants.searchBox))
      .sendKeys('chicago il')
      .then(() => {
        browser.element(by.css(MapConstants.searchButton)).click();
      });

    browser.switchTo().defaultContent();
  });

  it('should click a streetlight', async function() {
    const iframe = browser.element(by.id(MapConstants.iFrame))
    browser.sleep(5000); // wait for points to load.

    await browser.actions()
      .mouseMove(iframe) //moves the cursor to the CENTER of the passed in element
      .click(protractor.Button.LEFT)
      .perform();

    browser.sleep(10000);
  });

  fit('should zoom in', async function() {
    const iframe = browser.element(by.id(MapConstants.iFrame))
    browser.sleep(5000); // wait for points to load.

    await browser.actions()
      .mouseMove(iframe, {x: 100, y: 200}) // move to a place without a streetlight
      .doubleClick(protractor.Button.LEFT)
      .perform();

      //browser.sleep(10000);
  });

  it('should pan the map', async function () {
    const iframe = browser.element(by.id(MapConstants.iFrame)).getWebElement();
    
    browser.switchTo().frame(iframe).then(async function() {
      const canvas = browser.element(by.tagName("canvas"))
      
      await browser.actions()
        .mouseMove(canvas, { x: 50, y: 50 })
        .perform()
        .then(() => browser.actions().mouseDown(canvas).perform())
        .then(() => browser.actions().mouseMove(canvas, { x: 250, y: 250 }).perform())
        .then(() => browser.actions().mouseUp(canvas).perform());

      browser.switchTo().defaultContent();
    });

    browser.sleep(5000)
  });

  it('should click on an in progress light', async function() {
    const iframe = browser.element(by.id(MapConstants.iFrame))
    browser.sleep(5000); // wait for points to load.

    // place a marker
    await browser.actions()
      .mouseMove(iframe)
      .click(protractor.Button.RIGHT)
      .perform().then(() => {

        // click the marker
        browser.actions()
        .click(protractor.Button.LEFT)
        .perform();
      });

    browser.sleep(10000);
  });

  it('should call the api', function(done) {
    Request.get({
      "headers": { "content-type": "application/json" },
      "url": "https://services.arcgis.com/T2graiaSQnlmwwmp/arcgis/rest/services/Streetlights_SLALOM_SOAR/FeatureServer/0/query?f=pjson"
      }, (error, response, body) => {

        expect(response.statusCode).toBe(200)
        done();
    });
  });
});
