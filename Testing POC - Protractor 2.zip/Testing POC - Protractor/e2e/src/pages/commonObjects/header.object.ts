// import { ElementFinder, element, by } from "protractor";
// import { PromiseHandler } from "../../util/promise-handler";
// import { DashboardConstants } from "../../util/constants/dashboard-constants";

// export class HeaderObject extends PromiseHandler {
//   constructor() {
//     super(element(by.id(DashboardConstants.headerContainer)));
//   }

//   // Get Page Header
//   get PageHeader(): ElementFinder {
//     return this.getElementByAttribute(DashboardConstants.dashboardTitle);
//   }

//   // Get Button
//   get DashboardTab(): ElementFinder {
//     return this.getElementByAttribute(DashboardConstants.dashboardTab);
//   }

//   // Get Button
//   get HerosTab(): ElementFinder {
//     return this.getElementByAttribute(DashboardConstants.herosTab);
//   }

//   // Returns a boolean - true if all elements are displayed, false if not
//   async isDisplayed(): Promise<boolean> {
//     const result: boolean[] = await Promise.all([
//       await this.PageHeader.isDisplayed(),
//       await this.DashboardTab.isDisplayed(),
//       await this.HerosTab.isDisplayed(),
//     ]);
//     return result.every((val) => val === true);
//   }
// }
