// import { ElementFinder } from "protractor";
// import { DetailsPageConstants } from "../util/constants/detail-constants";
// import { PromiseHandler } from "../util/promise-handler";
// import { HeaderObject } from "./commonObjects/header.object";

// export default class DetailsPage extends PromiseHandler {
//   constructor(container: ElementFinder) {
//     super(container);
//   }

//   // Get the Search section
//   async headerSection(): Promise<HeaderObject> {
//     return new HeaderObject();
//   }

//   // Get Top Hero Title
//   get getDetailsPageTitle(): ElementFinder {
//     return this.getElementByAttribute(DetailsPageConstants.detailsPageHeader);
//   }

//   // Get Hero id
//   get getHeroId(): ElementFinder {
//     return this.getElementByAttribute(DetailsPageConstants.heroId);
//   }

//   // Get Text Box Header
//   get getInputBoxHeader(): ElementFinder {
//     return this.getElementByAttribute(DetailsPageConstants.nameTextBoxTitle);
//   }

//   // Get Textbox Input
//   get getInputBox(): ElementFinder {
//     return this.getElementByAttribute(DetailsPageConstants.nameTextboxinput);
//   }

//   // Get Go Back Button
//   get getGoBackButton(): ElementFinder {
//     return this.getElementByAttribute(DetailsPageConstants.goBackButton);
//   }

//   // Get Save Button
//   get getSaveButton(): ElementFinder {
//     return this.getElementByAttribute(DetailsPageConstants.saveButton);
//   }

//   // Returns a boolean - true if all elements are displayed, false if not
//   async isDisplayed(): Promise<boolean> {
//     const result: boolean[] = await Promise.all([
//       await (await this.headerSection()).isDisplayed(),
//       await this.getDetailsPageTitle.isDisplayed(),
//       await this.getInputBoxHeader.isDisplayed(),
//       await this.getHeroId.isDisplayed(),
//       await this.getInputBox.isDisplayed(),
//       await this.getGoBackButton.isDisplayed(),
//       await this.getSaveButton.isDisplayed(),
//     ]);
//     return result.every((val) => val === true);
//   }
// }
