// import { ElementFinder } from "protractor";
// import { PromiseHandler } from "../../util/promise-handler";
// import { DashboardConstants } from "../../util/constants/dashboard-constants";

// export class SearchObject extends PromiseHandler {
//   constructor(container: ElementFinder) {
//     super(container);
//   }

//   // Get Button
//   get SearchHeader(): ElementFinder {
//     return this.getElementInsideContainerByAttribute(
//       DashboardConstants.searchTitle
//     );
//   }

//   // Get Button
//   get SearchInput(): ElementFinder {
//     return this.getElementInsideContainerByAttribute(
//       DashboardConstants.searchInput
//     );
//   }

//   // Search Results
//   async SearchResults(): Promise<string[]> {
//     return (async () => {
//       const heroArray: string[] = [];
//       const searchResults = await this.getElementsByAttribute(
//         DashboardConstants.searchResult
//       ).getText();

//       for (const hero of searchResults) {
//         heroArray.push(hero);
//       }

//       return heroArray;
//     })();
//   }

//   // Returns a boolean - true if all elements are displayed, false if not
//   async isDisplayed(): Promise<boolean> {
//     const result: boolean[] = await Promise.all([
//       await this.SearchHeader.isDisplayed(),
//       await this.SearchInput.isDisplayed(),
//     ]);
//     return result.every((val) => val === true);
//   }
// }
