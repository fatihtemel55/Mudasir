// import { ElementFinder, ElementArrayFinder } from "protractor";
// import { PromiseHandler } from "../../util/promise-handler";
// import { DashboardConstants } from "../../util/constants/dashboard-constants";
// import { SearchObject } from "./search.object";
// import { HeaderObject } from "../commonObjects/header.object";

// export default class DashboardPage extends PromiseHandler {
//   constructor(container: ElementFinder) {
//     super(container);
//   }

//   // Get the Search section
//   async headerSection(): Promise<HeaderObject> {
//     return new HeaderObject();
//   }

//   // Get Top Hero Title
//   get topHerosTitle(): ElementFinder {
//     return this.getElementByAttribute(DashboardConstants.dashboardPageHeader);
//   }

//   // Get All the Top Hero Buttons
//   async topHerosButtons(): Promise<ElementFinder[]> {
//     const heros = await this.getElementsByAttribute(
//       DashboardConstants.heroButton
//     );
//     const herosButtons: ElementFinder[] = [];
//     for (let hero of heros) {
//       herosButtons.push(hero);
//     }

//     return herosButtons;
//   }

//   // Get the Search section
//   async searchSection(): Promise<SearchObject> {
//     const searchSectionContainer = this.getElementByAttribute(
//       DashboardConstants.searchContainer
//     );
//     return new SearchObject(searchSectionContainer);
//   }

//   // Returns a boolean - true if all elements are displayed, false if not
//   async isDisplayed(): Promise<boolean> {
//     const result: boolean[] = await Promise.all([
//       await (await this.headerSection()).isDisplayed(),
//       await this.topHerosTitle.isDisplayed(),
//       await (await this.topHerosButtons()[0]).isDisplayed(),
//       await (await this.searchSection()).isDisplayed(),
//     ]);
//     return result.every((val) => val === true);
//   }
// }
