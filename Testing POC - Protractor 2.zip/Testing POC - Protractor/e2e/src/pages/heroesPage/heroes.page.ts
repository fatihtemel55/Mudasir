// import { HeroesConstants } from "../../util/constants/heroes-constants";
// import { ElementFinder, by, promise, ElementArrayFinder, element } from "protractor";
// import { PromiseHandler } from "../../util/promise-handler";
// import { HeaderObject } from "../commonObjects/header.object";

// export default class HeroesPage extends PromiseHandler {
//   constructor(container: ElementFinder) {
//     super(container);
//   }

//   async headerSection(): Promise<HeaderObject> {
//     return new HeaderObject();
//   }

//   get myHeroesTitle(): ElementFinder {
//     return this.getElementInsideContainerByAttribute(
//       HeroesConstants.myHeroesTitle
//     );
//   }

//   get heroName(): ElementFinder {
//     return this.getElementInsideContainerByAttribute(
//       HeroesConstants.heroName
//     );
//   }

//   get heroAddButton(): ElementFinder {
//     return this.getElementInsideContainerByAttribute(
//       HeroesConstants.heroAddButton
//     );
//   }

//   get heroBadge(): ElementFinder {
//     return this.getElementInsideContainerByAttribute(
//       HeroesConstants.heroBadge
//     );
//   }

//   get heroBadgeAll(): ElementArrayFinder {
//     return this.getElementsInsideContainerByAttribute(HeroesConstants.heroList)
//   }

//   get heroDelete(): ElementFinder {
//     return this.getElementInsideContainerByAttribute(
//       HeroesConstants.heroDelete
//     );
//   }

//   get heroInputField(): ElementFinder {
//     return this.getElementInsideContainerByAttribute(
//       HeroesConstants.heroInputField
//     );
//   }

//   addToHeroName(text: string): promise.Promise<void> {
//     let input = this.getElementByCss("input");
//     return input.sendKeys(text);
//   }

//   getHeroAEltById(id: number): ElementFinder {
//     let spanForId = this.getElementByCssContainingText(
//       "li span.badge", id.toString()
//     );
//     return spanForId.element(by.xpath(".."));
//   }

//   getHeroLiEltById(id: number): ElementFinder {
//     let spanForId = this.getElementByCssContainingText(
//       "li span.badge", id.toString()
//     );
//     return spanForId.element(by.xpath("../.."));
//   }

//   getHeroBadgeByText(text: string): ElementArrayFinder {
//     return element.all(by.xpath(`//*[contains(text(), "${text}")]`));
//   }

//   // Returns a boolean - true if all elements are displayed, false if not
//   async isDisplayed(): Promise<boolean> {
//     const result: boolean[] = await Promise.all([
//       await this.myHeroesTitle.isDisplayed(),
//       await this.heroName.isDisplayed(),
//       await this.heroAddButton.isDisplayed(),
//       await this.heroBadge.isDisplayed(),
//       await this.heroDelete.isDisplayed(),
//     ]);
//     return result.every((val) => val === true);
//   }
// }
