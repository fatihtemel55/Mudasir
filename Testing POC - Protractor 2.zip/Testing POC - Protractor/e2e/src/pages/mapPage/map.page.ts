import { ElementFinder, ElementArrayFinder } from "protractor";
import { PromiseHandler } from "../../util/promise-handler";
import { MapConstants } from "../../util/constants/map-constants";

export default class MapPage extends PromiseHandler {
  constructor(container: ElementFinder) {
    super(container);
  }

  get SearchBar(): ElementFinder {
      return this.getElementByClass(MapConstants.searchBox);
  }

  // Returns a boolean - true if all elements are displayed, false if not
  // async isDisplayed(): Promise<boolean> {
  //   const result: boolean[] = await Promise.all([
  //       await this.SearchBar.isDisplayed(),
  //   ]);
  //   return result.every((val) => val === true);
  // }
}
