import { $, $$, by, element, ElementFinder } from "protractor";

export abstract class PromiseHandler {
  protected constructor(protected container: ElementFinder) {}

  protected getElementByAttribute = (dhc: string) =>
    element(by.css(`[data-automation=${dhc}]`));

  protected getElementInsideContainerById = (dhc: string) =>
    this.container.$(`#${dhc}`);
  protected getElementInsideContainerByClass = (dhc: string) =>
    this.container.$(`.${dhc}`);
  protected getElementInsideContainerByAttribute = (dhc: string) =>
    this.container.element(by.css(`[data-automation=${dhc}]`));

  protected getElementById = (dhc: string) => $(`#${dhc}`);
  protected getElementByClass = (dhc: string) => $(`.${dhc}`);
  protected getElementsByClass = (dhc: string) => $$(`.${dhc}`);
  protected getElementsById = (dhc: string) => $$(`#${dhc}`);
  protected getElementsByAttribute = (dhc: string) =>
    element.all(by.css(`[data-automation=${dhc}]`));
  protected getElementsInsideContainerByAttribute = (dhc: string) =>
    element.all(by.css(`[data-automation=${dhc}]`));
  protected getElementsInsideContainerById = (dhc: string) =>
    element.all(by.id(`#${dhc}]`));
  protected getElementByCss = (dhc: string) =>
    element(by.css(dhc));
  protected getElementByCssContainingText = (dhc: string, text: string) =>
    element(by.cssContainingText(dhc, text));
}
