import { browser, by, element, protractor } from "protractor";

export class HelperMethods {
  static async navigateToMap(timeout): Promise<void> {
    await browser.get(`${browser.baseUrl}`);
    browser.sleep(timeout);
  }

  // static async navigateToDashboard(): Promise<void> {
  //   await browser.get(`${browser.baseUrl}dashboard`);
  // }

  // static async navigateToHeroes(): Promise<void> {
  //   await browser.get(`${browser.baseUrl}heroes`);
  // }
}
