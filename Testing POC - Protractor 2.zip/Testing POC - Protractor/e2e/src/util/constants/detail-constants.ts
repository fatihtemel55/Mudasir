// // Used to find elements on various action sections (accessed via details pages)

// export class DetailsPageConstants {
//   static detailsPageContainer = "QE-Details-PageContainer";
//   static detailsPageHeader = "QE-Details-PageHeader";
//   static heroId = "QE-Details-HeroId";
//   static nameTextBoxTitle = "QE-Details-NameTextBoxTitle";
//   static nameTextboxinput = "QE-Details-NameTextboxinput";
//   static goBackButton = "QE-Details-GoBackButton";
//   static saveButton = "QE-Details-SaveButton";
// }
