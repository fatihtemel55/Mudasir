// Used to find elements on various action sections (accessed via details pages)

//export class DashboardConstants {
  // static dashboardTitle = "QE-Dashboard-DashboardTitle";
  // static dashboardTab = "QE-Dashboard-DashboardTab";
  // static herosTab = "QE-Dashboard-HerosTab";
  // static headerContainer = "QE-HeaderToolBar";

  // static dashboardContainer = "QE-Dashboard-dashboardContainer";
  // static dashboardPageHeader = "QE-Dashboard-PageHeader";
  // static heroButton = "QE-Dashboard-HeroButton";
  // static heroName = "QE-Dashboard-HeroName";

  // // Search Section
  // static searchTitle = "QE-Dashboard-SearchTitle";
  // static searchInput = "QE-Dashboard-SearchInput";
  // static searchContainer = "QE-Dashboard-SearchContainer";
  // static searchResultContainer = "QE-Dashboard-SearchResultContainer";
  // static searchResult = "QE-Dashboard-SearchResult";
//}
