// Used to find elements on various action sections (accessed via details pages)

export class MapConstants {
  static iFrame = "result";
  static mapContainer = ".esri-view-root";
  static searchBox = ".esri-input.esri-search__input";
  static searchButton = ".esri-search__submit-button.esri-widget--button";
}
