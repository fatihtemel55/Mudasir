// export class HeroesConstants {
//   static myHeroesTitle = "QE-Heroes-MyHeroesTitle";
//   static heroName = "QE-Heroes-HeroName";
//   static heroAddButton = "QE-Heroes-heroAddButton";
//   static heroBadge = "QE-Heroes-heroBadge";
//   static heroDelete = "QE-Heroes-heroDelete";
//   static heroInputField = "QE-Heroes-heroInputField";
//   static heroList = "QE-Heroes-heroList";
// }
